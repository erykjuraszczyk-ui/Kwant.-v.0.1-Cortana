"""Moduły percepcji danych wejściowych."""
