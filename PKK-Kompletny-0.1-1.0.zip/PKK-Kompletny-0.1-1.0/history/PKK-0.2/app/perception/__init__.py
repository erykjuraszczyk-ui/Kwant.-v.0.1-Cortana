"""Moduły percepcji PKK."""
